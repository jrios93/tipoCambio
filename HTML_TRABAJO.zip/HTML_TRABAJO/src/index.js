const price = document.getElementById("price");
const tc = document.getElementById("tc");
const result = document.getElementById("result");
const buttonSave = document.getElementById("saveResult");
const buttonDelete = document.getElementById("delete");
const listResultSave = document.getElementById("listSave");
const withoutDiscountRadio = document.getElementById("withoutDiscount");
const discountRadio1 = document.getElementById("discount1");
const discountRadio1_5 = document.getElementById("discount1_5");
const discountRadio2 = document.getElementById("discount2");

// Funcion para aplicar descuento

function applyDiscount(result) {
  if (withoutDiscountRadio.checked) {
    return result;
  } else if (discountRadio1.checked) {
    return result * 0.99;
  } else if (discountRadio1_5.checked) {
    return result * 0.985;
  } else if (discountRadio2.checked) {
    return result * 0.98;
  }
}

// Funcion para calcular importe
function calculate() {
  const value1 = parseFloat(price.value);
  const value2 = parseFloat(tc.value);

  if (!isNaN(value1) && !isNaN(value2)) {
    const answer = Number(value1 * 1.18).toFixed(2);
    const resultDiscount = Number(applyDiscount(answer)).toFixed(2);
    const resultFinal = Number(resultDiscount * value2).toFixed(2);

    result.innerHTML = `Precio Incluido:  <strong>$${resultDiscount}</strong><br> t/c: <strong>${value2}</strong><br> Precio Soles: <strong>S/${resultFinal}</strong> `;
  } else {
    result.innerHTML = "Resultado Invalido";
  }
}

// Funcion para guardar resultados
function savingResult() {
  const result1 = result.textContent;
  if (result1 !== "Resultado Invalido") {
    const resultsSaved = localStorage.getItem("listSave") || "[]";
    const parseResultsSaved = JSON.parse(resultsSaved);
    parseResultsSaved.push(result1);
    localStorage.setItem("listSave", JSON.stringify(parseResultsSaved));
    viewResult();
  }
}

// Eliminar resultados

function deleteResult() {
  localStorage.removeItem("listSave");
  listResultSave.innerHTML = "";
}

// Funcion para mostrar resultado
function viewResult() {
  listResultSave.innerHTML = "";
  const resultsSaved = localStorage.getItem("listSave");
  if (resultsSaved) {
    const parseResultsSaved = JSON.parse(resultsSaved);
    parseResultsSaved.forEach((result) => {
      const listItem = document.createElement("li");
      listItem.textContent = result;
      listResultSave.appendChild(listItem);
    });
  }
}

price.addEventListener("input", calculate);
tc.addEventListener("input", calculate);
withoutDiscountRadio.addEventListener("change", calculate);
discountRadio1.addEventListener("change", calculate);
discountRadio1_5.addEventListener("change", calculate);
discountRadio2.addEventListener("change", calculate);
buttonSave.addEventListener("click", savingResult);
buttonDelete.addEventListener("click", deleteResult);
viewResult();
